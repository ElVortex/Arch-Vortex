# i3lock-blur

simplest i3lock blur script only requirements is `ffmpeg` and `xrandr`

example: [video](https://gfycat.com/SentimentalTemptingElephantbeetle)

## simple usecase:

1. put lock.png and lock.sh to the home folder
2. chmod +x lock.sh
3. add i3 config: `bindsym $mod+q exec ~/lock.sh` to bind lock to `mod+q`
4. PROFIT!!!

[reddit link](https://www.reddit.com/r/unixporn/comments/4yj29e/i3lock_simple_blur_script/)
