require('configuration.client.rules')
