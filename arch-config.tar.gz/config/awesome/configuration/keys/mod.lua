return {
    modKey = 'Mod4',
    altKey = 'Mod1'
}