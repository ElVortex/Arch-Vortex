return {
  keys = require('configuration.keys'),
  apps = require('configuration.apps')
}
